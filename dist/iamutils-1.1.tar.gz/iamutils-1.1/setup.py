#!/usr/bin/env python
from distutils.core import setup

setup(name='iamutils',
      version='1.1',
      description='CongVM Utilities',
      author='congvm',
      author_email='congvm.it@gmail.com',
      license='MIT',
      url='https://github.com/vocong25/iamutils.git'
     )