# __init__.py
__version__ = "1.0"
__doc__ = 'I am utils package by congvm'


from .src.downloader import download_image_by_url
from .src.downloader import get_image_from_url
from .src.multi_processing import pool_worker

