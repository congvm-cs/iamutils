#!/usr/bin/env python
from distutils.core import setup

setup(name='i-am-utils',
      version='1.0',
      description='useful utilities',
      author='congvm',
      author_email='congvm.it@gmail.com',
      license='MIT',
      url='https://github.com/vocong25/iamutils.git',
      packages=["iamutils"]
     )